
import { PrismaClient } from '@prisma/client'
import bcrypt from 'bcryptjs'
const prisma = new PrismaClient()

async function main(){
  const hash = await bcrypt.hash('admin123',10)
  await prisma.user.create({
    data:{ email:'admin@bank.com', password:hash }
  })
}
main()
