
'use client'
import { useState } from 'react'
import axios from 'axios'

export default function Login(){
  const [email,setEmail]=useState('')
  const [password,setPassword]=useState('')

  const submit = async ()=>{
    const res = await axios.post('/api/auth/login',{email,password})
    alert(JSON.stringify(res.data))
  }

  return (
    <div style={{padding:40}}>
      <h1>Login</h1>
      <input placeholder="email" onChange={e=>setEmail(e.target.value)} />
      <input placeholder="password" type="password" onChange={e=>setPassword(e.target.value)} />
      <button onClick={submit}>Login</button>
    </div>
  )
}
